"use strict"; //Deactivated on the tsconfig.json file.

// The module 'vscode' contains the VS Code extensibility API
import * as vscode from "vscode"; // Import the module and reference it with the alias vscode in your code below

export function activate(context: vscode.ExtensionContext) {// This method is called when your extension is activated
  // Your extension is activated the very first time the command is executed
  let disposable = vscode.commands.registerCommand("extension.gapline", () => {//Comando para llamar extensión. Se debe de cambiar en el package
    var editor = vscode.window.activeTextEditor; //Inicializa variable del editor de texto
    if (!editor) {//Valida que no exista una sesión de edición abierta
      return; //no realizara nada
    }
    var selection = editor.selection; // El programa recorrerá solo el texto seleccionado 
    var text = editor.document.getText(selection); //Guarda el texto seleccionado por el usuario

    vscode.window.showInputBox({ prompt: "Lineas?" }).then((value) => {
      //Entrada de número de líneas a saltar, después de enter la función sigue
      let numberOfLines = +value; //Crea variable de saltos de linea
      var textInChunks: Array<string> = []; //Crea array vacio

      text.split("\n").forEach((currentLine: string, lineIndex) => {
        //Invoca a la función "split" para detectar cada salto de línea y recorre los datos completos con un ForEach.
        textInChunks.push(currentLine); //Agrega al array vacío el contenido de cada línea
        if ((lineIndex + 1) % numberOfLines === 0) textInChunks.push(""); //Valida los saltos correspondiente a realizar
      });

      text = textInChunks.join("\n"); //Agrega los saltos al array con salto de línea 
      editor.edit((editBuilder) => { //invoca la funcion para realizar el salto
        var range = new vscode.Range( //pivote para realizar el salto
          selection.start.line,0, selection.end.line, //inicio de conteo de lineas a partir de 0
          editor.document.lineAt(selection.end.line).text.length //indica el último elemento
        );
        editBuilder.replace(range, text);//Siguiente línea a iterar
      });
    });
  });
  context.subscriptions.push(disposable); //Variable de entorno
}

export function deactivate() {} //Extension in deactivated: Calls this function in case the ext. is no longer required by the user